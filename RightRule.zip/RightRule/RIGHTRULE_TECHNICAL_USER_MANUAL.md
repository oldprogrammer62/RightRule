# RightRule Technical User Manual

## Overview

RightRule is a .NET 8 rules engine for evaluating text-based rule statements against named datasets. A rule belongs to a context, has an evaluation order, and returns a decision when its statement evaluates successfully. Applications can register rules and data early at startup, or provide data at the point of evaluation.

The main library is in `src/RightRule.csproj`. The public entry point is `RightRule.RightRule`.

## Project Components

- `src/`: core RightRule engine, parser, evaluator, data converters, and default operators.
- `rightrule.system.common/`: shared contracts, including `IOperator` and `RulesToReturn`.
- `rightrule.operator.loader/`: dynamic custom operator loader.
- `RightRule_Demo/`: example console application.
- `AgeChecker/`: console application that uses the age verification operator.
- `test/RightRule.UnitTest/`: xUnit tests.

## Build and Test

From the repository root:

```bash
dotnet restore RightRule.sln
dotnet build RightRule.sln
dotnet test test/RightRule.UnitTest/RightRuleTests.csproj
```

Run the demo:

```bash
dotnet run --project RightRule_Demo/RightRule_Demo.csproj
```

Run AgeChecker:

```bash
dotnet run --project AgeChecker/AgeChecker.csproj
```

Run AgeChecker in Docker:

```bash
docker build -f AgeChecker/Dockerfile -t agechecker .
docker run --rm -it agechecker
```

## Core Concepts

### RuleDefinition

Use `RuleDefinition` to define a rule before registration.

```csharp
new RuleDefinition
{
    Number = 1,
    Name = "Find adult",
    Context = "AgeCheck",
    Statement = "DateOfBirth ageverified 18",
    Decision = "AGE_VERIFIED",
    DecisionData = "Person is over 18."
};
```

Properties:

- `Number`: rule order; lower numbers are evaluated first.
- `Name`: descriptive rule name for logging or diagnostics.
- `Context`: group name used to select rules at evaluation time.
- `Statement`: RightRule expression to evaluate.
- `Decision`: string returned on a successful rule match.
- `DecisionData`: optional additional result payload.
- `Arguments`: optional placeholder values used in reusable statements.

### Datasets

Datasets are registered under a name and evaluated by rules. The easiest input is `Dictionary<string, object>`.

```csharp
rightRule.RegisterData("Customer", new Dictionary<string, object>
{
    ["age"] = 25,
    ["name"] = "Harry",
    ["goodpayer"] = true
});
```

`RegisterData<T>` also accepts objects with public properties and enumerable values. Objects are converted using property names. Enumerables are converted using numeric string keys such as `"0"`, `"1"`, and `"2"`; for normal rule statements, prefer dictionaries or objects with named fields.

## Basic Usage

```csharp
using RightRule.Rules;
using RightRule.System.Common;

var rightRule = new RightRule.RightRule();

rightRule.RegisterRule(new RuleDefinition
{
    Number = 1,
    Name = "Good payer",
    Context = "CustomerDecision",
    Statement = "numberoforders equals 10 and goodpayer equals true",
    Decision = "APPROVE"
});

rightRule.RegisterData("Customer", new Dictionary<string, object>
{
    ["numberoforders"] = 10,
    ["goodpayer"] = true
});

var result = rightRule.ApplyRule("CustomerDecision", "Customer");

if (result.Result)
{
    Console.WriteLine(result.Decision);
}
```

## Rule Statement Syntax

Rule statements use a small expression language:

```text
expr       ::= or
or         ::= and ("OR" and)*
and        ::= not ("AND" not)*
not        ::= "NOT" not | primary
primary    ::= "(" expr ")" | condition
condition  ::= variable operator value
value      ::= number | string | boolean | identifier | placeholder
placeholder ::= "{" identifier "}"
```

Examples:

```text
age equals 20
age = 20
age = 20 AND name = "Harry"
(age = 20 OR name = "Harry") AND goodpayer equals true
NOT status equals "blocked"
DateOfBirth ageverified 18
```

Logical keywords are case-insensitive. String literals must use double quotes. Variables must match keys in the registered dataset.

## Built-In Operators

Default operators are registered automatically.

| Operator | Identifiers | Behavior |
| --- | --- | --- |
| Equals | `equals`, `eq`, `=`, `==` | Uses .NET object equality. |
| Not equals | `notequals`, `neq`, `!=`, `<>` | Negates object equality. |
| Contains | `contains` | Case-insensitive string containment. |
| Age verified | `ageverified`, `isoverage` | Returns true when a date of birth is at least the minimum age. |

The age operator accepts `DateOnly`, `DateTime`, or parseable date strings on the left side, and an integer minimum age on the right side.

## Placeholders and Arguments

Use placeholders to define reusable rules.

```csharp
rightRule.RegisterRule(new RuleDefinition
{
    Number = 1,
    Name = "Expected status",
    Context = "OrderDecision",
    Statement = "status equals {ExpectedStatus}",
    Decision = "STATUS_MATCHED",
    Arguments = new Dictionary<string, object>
    {
        ["ExpectedStatus"] = "approved"
    }
});
```

Placeholders are written as `{Name}`. During evaluation, placeholder values are resolved from `Arguments`.

## Applying Rules

Use `ApplyRule` when you want the first successful rule.

```csharp
AppliedRule result = rightRule.ApplyRule("CustomerDecision");
AppliedRule resultForDataset = rightRule.ApplyRule("CustomerDecision", "Customer");
```

Use `ApplyRules` when you want a list of evaluated rules.

```csharp
List<AppliedRule> allResults = rightRule.ApplyRules("CustomerDecision");
List<AppliedRule> firstAsList = rightRule.ApplyRules("CustomerDecision", RulesToReturn.First);
```

`AppliedRule` includes:

- `Result`: whether the rule evaluated true.
- `Decision`: the decision string from the rule.
- `DecisionData`: optional payload from the rule.
- `DatasetMatched`: dataset name used during evaluation.
- `StatementApplied`: statement after placeholder replacement.

Always check `Result` before acting on `Decision`, especially when using dataset-specific evaluation.

## Rule and Data Lifecycle

Register rules with:

```csharp
rightRule.RegisterRule(rule);
rightRule.RegisterRules(rules);
```

Remove rules by context:

```csharp
rightRule.DeRegisterRules("CustomerDecision");
```

Register and remove datasets:

```csharp
rightRule.RegisterData("Customer", data);
rightRule.DeRegisterData("Customer");
```

`RightRule` keeps registered rules and datasets in memory for the lifetime of the instance unless they are deregistered.

## Custom Operators

Custom operators implement `RightRule.System.Common.IOperator`.

```csharp
using RightRule.System.Common;

public sealed class StartsWithOperator : IOperator
{
    public List<string> Identifiers => ["startswith"];

    public bool Process(object left, object right)
    {
        return left?.ToString()?.StartsWith(
            right?.ToString() ?? string.Empty,
            StringComparison.OrdinalIgnoreCase) == true;
    }
}
```

Custom operators are loaded from paths listed in the JSON file configured by `CustomOperatorConfigPath` in `src/rightrule.dll.config`.

```json
{
  "operators": [
    {
      "name": "StartsWith",
      "path": "C:\\Path\\To\\Operator.startswith.dll"
    }
  ]
}
```

Operator identifiers must be unique across built-in and custom operators.

## Error Handling

Invalid contexts, missing datasets, unknown variables, unknown operators, or malformed statements can produce default rules or exceptions depending on the API path. A default rule has:

```text
Decision = "NODECISION"
DatasetMatched = "NO_DATASET_MATCHED"
Number = -1
```

For reliable application logic:

1. Validate rule syntax before production use.
2. Ensure dataset keys match statement variable names exactly.
3. Check `AppliedRule.Result` before acting on `Decision`.
4. Log `StatementApplied` and `DatasetMatched` for diagnostics.

## AgeChecker Example

`AgeChecker` is a console app that prompts for a date of birth and verifies that the person is over 18.

Rule used:

```text
DateOfBirth ageverified 18
```

Example Docker run:

```bash
docker run --rm -it agechecker
```

Example non-interactive checks:

```bash
printf '2000-01-01\n' | docker run --rm -i agechecker
printf '2010-01-01\n' | docker run --rm -i agechecker
```

## Performance Notes

For small rule sets, RightRule can be used directly. For large rule and dataset collections, consider the notes in `MEMORY_AND_PERFORMANCE_NOTES.md`: rules are filtered and sorted on each apply call, named dataset lookup is linear, and object conversion uses reflection.
