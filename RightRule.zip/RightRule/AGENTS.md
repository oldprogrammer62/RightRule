# Repository Guidelines

## Project Structure & Module Organization

RightRule is a .NET 8 C# solution centered on `RightRule.sln`. The main rules engine lives in `src/`, with rule registration/application code in `src/Rules/`, data handling in `src/Data/` and `src/DataConverters/`, operator loading in `src/Operators/`, and parsing/evaluation logic in `src/StatementProcessor/`. Shared operator contracts are in `rightrule.system.common/`, and dynamic operator loading support is in `rightrule.operator.loader/`.

Example/custom operators are separate projects: `Operator.greaterthanorequals/`, `Operator.lessthan/`, and `operator.doesnotcontain/`. The runnable sample app is `RightRule_Demo/`. Unit tests are under `test/RightRule.UnitTest/`.

## Build, Test, and Development Commands

Run these from the repository root:

```bash
dotnet restore RightRule.sln
dotnet build RightRule.sln
dotnet test test/RightRule.UnitTest/RightRuleTests.csproj
dotnet run --project RightRule_Demo/RightRule_Demo.csproj
```

`restore` resolves NuGet dependencies, `build` compiles all projects, `test` runs the xUnit suite, and `run` starts the demo application. Use `dotnet test --collect:"XPlat Code Coverage"` when coverage output is needed through the existing Coverlet collector.

## Coding Style & Naming Conventions

Use C# with nullable reference types and implicit usings enabled, matching the project files. Keep four-space indentation and place braces on their own lines, consistent with the existing code. Public types and methods use PascalCase, private fields commonly use an underscore prefix such as `_Data`, and local variables use camelCase. Keep rule-engine names descriptive: `RuleDefinition`, `AppliedRule`, `DataRegistrationService`, etc.

## Testing Guidelines

Tests use xUnit (`[Fact]`) and live in `test/RightRule.UnitTest/`. Add tests beside related coverage, for example parser behavior in `GrammarTests.cs` or operator behavior in `LessThanTests.cs`. Test method names should describe the scenario and expected behavior, following existing patterns such as `TestItWorks_Number_Equals`. Cover both matching and non-matching rule outcomes, including the default rule path.

## Commit & Pull Request Guidelines

Recent commits use short, imperative summaries such as `Removed commented code` and `Tests to cover named datasets`. Keep commit messages concise and focused on one change.

Pull requests should include a brief description, the reason for the change, and the test command run. Link related issues when available. For parser, rule, or operator changes, include representative rule statements or demo output so reviewers can quickly verify behavior.

## Security & Configuration Tips

Custom operators are loaded from DLLs and configuration files under `src/Operators/CustomOperators/`. Treat new operator binaries as executable code: document their source, keep matching config updates nearby, and avoid committing machine-specific paths or secrets.
