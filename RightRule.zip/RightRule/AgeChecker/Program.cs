using RightRule.Rules;

Console.WriteLine("AgeChecker");
Console.Write("Enter date of birth: ");

var input = Console.ReadLine();
if (!DateOnly.TryParse(input, out var dateOfBirth))
{
    Console.WriteLine("Invalid date of birth.");
    return;
}

var rightRule = new RightRule.RightRule();
rightRule.RegisterRule(new RuleDefinition
{
    Number = 1,
    Name = "Age verification",
    Context = "AgeCheck",
    Statement = "DateOfBirth ageverified 18",
    Decision = "AGE_VERIFIED",
    DecisionData = "Person is over 18."
});

rightRule.RegisterData("Person", new Dictionary<string, object>
{
    ["DateOfBirth"] = dateOfBirth
});

var appliedRule = rightRule.ApplyRule("AgeCheck", "Person");
if (appliedRule.Result && appliedRule.Decision == "AGE_VERIFIED")
{
    Console.WriteLine("Age verified.");
}
else
{
    Console.WriteLine("Age verification failed.");
}
