# Memory Leaks and Bottlenecks

## Memory Retention Risks

### Dynamic operator assemblies stay loaded

`rightrule.operator.loader/Loader.cs` creates a collectible `AssemblyLoadContext`, loads the operator assembly, and returns an `IOperator` instance. The context is never unloaded, and the returned operator is stored in `RightRuleService._operators`.

This is acceptable if operators are meant to live for the lifetime of a `RightRule` instance. If operators are loaded repeatedly or hot-reloaded, assemblies and types may remain alive longer than expected.

Suggested fix: document operator lifetime clearly, or introduce an owned disposable operator-load context if unload/reload support is required.

### Temporary datasets can remain registered after exceptions

`RightRuleService.ApplyRule<T>` and `RightRuleService.ApplySpecifiedRules<T>` register temporary data, apply rules, then deregister the dataset. If evaluation throws, deregistration is skipped.

Suggested fix: wrap temporary dataset registration in `try/finally`.

```csharp
RegisterData(DatasetName, Data);
try
{
    return ApplySpecifiedRules(Context, rulesToReturn);
}
finally
{
    DeRegisterData(DatasetName);
}
```

### Long-lived rule and dataset collections can grow unbounded

Registered rules and datasets are held strongly in `ParsedRules` and `RegisteredDatasets`. This is expected behavior, but long-lived services must call `DeRegisterRules` and `DeRegisterData` when entries are no longer needed.

Suggested fix: document lifecycle expectations and consider clearer APIs for clearing all rules or datasets.

## Performance Bottlenecks

### Rules are filtered and sorted on every apply call

`Helpers.FilterRules` scans all registered rules, filters by context, sorts by number, and allocates a new list each time rules are applied.

Suggested fix: group and sort rules by context at registration time, for example with a `Dictionary<string, List<ParsedRule>>`.

### Rule evaluation scales with rules multiplied by datasets

`ProcessAllRules` evaluates every filtered rule against every registered dataset. This is the natural behavior for `RulesToReturn.All`, but it becomes expensive as both collections grow.

Suggested fix: prefer dataset-specific apply calls when possible, and consider indexing datasets by name.

### Dataset lookup by name is linear

`RegisteredDatasets.GetDataset` uses `FirstOrDefault` over a list. Repeated named lookups become slower as dataset count grows.

Suggested fix: replace or supplement the list with a `Dictionary<string, RegisteredDataset>`.

### Applied rule statement resolution creates repeated strings

`Helper.ResolveStatement` recursively replaces placeholders and creates new strings for each replacement. This happens while creating `AppliedRule` results.

Suggested fix: resolve statements only when needed, or cache resolved statements per rule and argument set.

### Object conversion uses reflection repeatedly

`ObjectConverter.ConvertToDictionary` calls `typeof(T).GetProperties()` and `property.GetValue(data)` on each conversion.

Suggested fix: cache property metadata or compiled property accessors per type for repeated `ApplyRule<T>` calls.
