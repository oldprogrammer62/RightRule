using System.Globalization;
using RightRule.System.Common;

namespace RightRule.Operators.DefaultOperators;

public sealed class AgeVerifiedOperator : IOperator
{
    public List<string> Identifiers => ["ageverified", "isoverage"];

    public bool Process(object left, object right)
    {
        if (!TryGetDateOfBirth(left, out var dateOfBirth))
        {
            return false;
        }

        if (!TryGetMinimumAge(right, out var minimumAge))
        {
            return false;
        }

        var today = DateOnly.FromDateTime(DateTime.Today);
        var age = today.Year - dateOfBirth.Year;
        if (dateOfBirth > today.AddYears(-age))
        {
            age--;
        }

        return age >= minimumAge;
    }

    private static bool TryGetDateOfBirth(object value, out DateOnly dateOfBirth)
    {
        dateOfBirth = default;

        if (value is DateOnly dateOnly)
        {
            dateOfBirth = dateOnly;
            return true;
        }

        if (value is DateTime dateTime)
        {
            dateOfBirth = DateOnly.FromDateTime(dateTime);
            return true;
        }

        if (value is string text)
        {
            return DateOnly.TryParse(
                text,
                CultureInfo.CurrentCulture,
                DateTimeStyles.None,
                out dateOfBirth);
        }

        return false;
    }

    private static bool TryGetMinimumAge(object value, out int minimumAge)
    {
        minimumAge = default;

        if (value is int intValue)
        {
            minimumAge = intValue;
            return true;
        }

        if (value is long longValue && longValue <= int.MaxValue && longValue >= int.MinValue)
        {
            minimumAge = (int)longValue;
            return true;
        }

        if (value is decimal decimalValue
            && decimalValue % 1 == 0
            && decimalValue <= int.MaxValue
            && decimalValue >= int.MinValue)
        {
            minimumAge = (int)decimalValue;
            return true;
        }

        if (value is string text)
        {
            return int.TryParse(text, NumberStyles.Integer, CultureInfo.CurrentCulture, out minimumAge);
        }

        return false;
    }
}
