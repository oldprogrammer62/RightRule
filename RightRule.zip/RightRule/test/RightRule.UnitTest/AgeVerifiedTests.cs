using RightRule.Rules;

namespace RightRuleTests;

public class AgeVerifiedTests
{
    [Fact]
    public void TestItWorks_AgeVerified_Over18()
    {
        RuleDefinition rule = new()
        {
            Number = 1,
            Name = "Age verification",
            Statement = "DateOfBirth ageverified 18",
            Context = "AgeCheck",
            Decision = "AGE_VERIFIED",
        };

        RightRule.RightRule rr = new();
        rr.RegisterRule(rule);
        rr.RegisterData("Person", new Dictionary<string, object>
        {
            ["DateOfBirth"] = DateOnly.FromDateTime(DateTime.Today.AddYears(-19))
        });

        var appliedRule = rr.ApplyRule("AgeCheck", "Person");

        Assert.Equal(rule.Decision, appliedRule.Decision);
        Assert.True(appliedRule.Result);
    }

    [Fact]
    public void TestItWorks_AgeVerified_Under18()
    {
        RuleDefinition rule = new()
        {
            Number = 1,
            Name = "Age verification",
            Statement = "DateOfBirth ageverified 18",
            Context = "AgeCheck",
            Decision = "AGE_VERIFIED",
        };

        RightRule.RightRule rr = new();
        rr.RegisterRule(rule);
        rr.RegisterData("Person", new Dictionary<string, object>
        {
            ["DateOfBirth"] = DateOnly.FromDateTime(DateTime.Today.AddYears(-18).AddDays(1))
        });

        var appliedRule = rr.ApplyRule("AgeCheck", "Person");

        Assert.Equal(rule.Decision, appliedRule.Decision);
        Assert.False(appliedRule.Result);
    }
}
